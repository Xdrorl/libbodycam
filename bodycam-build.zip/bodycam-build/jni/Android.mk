LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := bodycam
LOCAL_SRC_FILES := bodycam.cpp
LOCAL_LDLIBS := -lOpenSLES -llog
LOCAL_CPPFLAGS := -std=c++17 -O2 -fvisibility=hidden
include $(BUILD_SHARED_LIBRARY)
